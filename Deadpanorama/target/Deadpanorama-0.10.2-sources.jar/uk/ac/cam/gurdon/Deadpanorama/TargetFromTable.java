package uk.ac.cam.gurdon.Deadpanorama;

public class TargetFromTable {

}
